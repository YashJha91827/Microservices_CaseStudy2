package com.main.service;

import java.util.List;

import com.main.model.Product;



public interface ProductServiceIntf {

	void saveProduct(Product product);

	List<Product> fetchData();	
}
